#!/bin/bash

DOMAIN="validatingwebhook.ex9.svc"
SERVER="webhook"
CPATH="certs"
mkdir -p $CPATH

# Create root CA & Private key
openssl req -x509 \
            -sha256 -days 365 \
            -nodes \
            -newkey rsa:2048 \
            -subj "/CN=${DOMAIN}/C=MY/L=PJ" \
            -keyout $CPATH/ca-cert.key -out $CPATH/ca-cert.crt 

# Generate Private key 
openssl genrsa -out $CPATH/${SERVER}.key 2048

# Create csf conf
cat <<EOF > $CPATH/csr.conf
[ req ]
default_bits = 2048
prompt = no
default_md = sha256
req_extensions = req_ext
distinguished_name = dn

[ dn ]
C = MY
ST = Selangor
L = Petaling Jaya
O = DevOps
OU = DevOps
CN = ${DOMAIN}

[ req_ext ]
subjectAltName = @alt_names

[ alt_names ]
DNS.1 = ${DOMAIN}
EOF

# create CSR request using private key

openssl req -new -key $CPATH/${SERVER}.key -out $CPATH/${SERVER}.csr -config $CPATH/csr.conf

# Create a external config file for the certificate

cat <<EOF > $CPATH/cert.conf
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names

[alt_names]
DNS.1 = ${DOMAIN}
EOF

# Create SSl with self signed CA
openssl x509 -req \
    -in $CPATH/${SERVER}.csr \
    -CA $CPATH/ca-cert.crt -CAkey $CPATH/ca-cert.key \
    -CAcreateserial -out $CPATH/${SERVER}.crt \
    -days 365 \
    -sha256 -extfile $CPATH/cert.conf

### generate the yaml manifests ###
