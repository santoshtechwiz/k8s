#!/bin/bash
## setup exam env for q13, q14 and q15
kubectl delete ns stress frontend backend test admission nginx demo demo2 bluegreen canary dev devspace
kubectl delete ingress ingress-foodvideo ingress-webapp
kubectl delete deployment app web food video ecommerce-logs probe dbserver nginx myweb nginx-sc webcm app-1 app-2 webserver
kubectl delete pod tiger elephant bb3 mybbox nginx-cm webserver myapp-pod myapp2-pod webapp --force
kubectl delete rs rs-myapp && kubectl delete svc mysvc
kubectl create ns xyz 
kubectl label ns xyz admission-webhook=enabled

kubectl create ns ex10
kubectl -n ex10 apply -f ~/mockexam/admin-pod.yaml 

kubectl create ns ex13
kubectl -n ex13 apply -f ~/ex-sol/q13

kubectl create ns ex14
kubectl -n ex14 create deployment food --image=quay.io/ocp4git/nginx-food
kubectl -n ex14 create deployment video --image=quay.io/ocp4git/nginx-video
kubectl -n ex14 create deployment web --image=quay.io/ocp4git/nginx-web

kubectl create ns ex15
kubectl -n ex15 create deployment blue --image=quay.io/ocp4git/app-blue
kubectl -n ex15 create deployment green --image=quay.io/ocp4git/app-green
kubectl -n ex15 create deployment red --image=quay.io/ocp4git/app-red
kubectl -n ex15 apply -f ~/ex-sol/q15/deny-ingress.yaml

