#!/bin/bash
#useradd -m jack && mkdir -p /home/jack/.kube && cp jack.conf /home/jack/.kube/config && chown -R jack:jack /home/jack/.kube
useradd -m jill && mkdir -p /home/jill/.kube && cp jill.conf /home/jill/.kube/config && chown -R jill:jill /home/jill/.kube

#usermod -s /bin/bash jack
usermod -s /bin/bash jill

