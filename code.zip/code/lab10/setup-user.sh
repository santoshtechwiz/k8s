#!/bin/bash
if [ -z $1 ]; then
   echo "Please specify user-name!"; exit;
fi 
USER=$1
touch $USER
KUBECONFIG=${USER}.conf kubectl config set-cluster kubernetes \
--server=https://master:6443 --certificate-authority ./ca.crt --embed-certs

KUBECONFIG=${USER}.conf kubectl config set-credentials $USER \
--client-key ./${USER}.key --client-certificate ./${USER}.crt --embed-certs

KUBECONFIG=${USER}.conf kubectl config set-context ${USER}def --cluster kubernetes --user $USER
KUBECONFIG=${USER}.conf kubectl config use-context ${USER}def


