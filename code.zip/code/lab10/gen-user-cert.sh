#!/bin/bash
if [ -z $1 ]; then
  echo "Please specify user-name! Eg: =>  ./gen-user-cert.sh jack"; exit;
fi
ssh root@master /root/master-infra/gen-users-master.sh $1
scp root@master:/root/users-x509/$1/* .
