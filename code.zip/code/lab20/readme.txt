There are no files for this lab, BUT, remember to make a backup copy of the 'kube-apiserver.yaml' file, i.e. 

$ ssh root@master

COPY the 'kube-apiserver.yaml' to the /root folder 
--------
root@master:~# cp /etc/kubernetes/manifests/kube-apiserver.yaml  /root/
