#!/bin/bash
curl -o get_helm.sh https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3
chmod 700 get_helm.sh && sudo ./get_helm.sh
