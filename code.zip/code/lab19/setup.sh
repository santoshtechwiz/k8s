#!/bin/bash

## create backend last because a default deny for ingress/egress will 
## also prevent DNS traffic - so it needs the env variables to access.
kubectl create ns backend
kubectl -n backend create deployment db --image=quay.io/ocp4git/nginx-app
kubectl -n backend expose deployment db --name=db --port=80 

kubectl create ns frontend 
kubectl -n frontend create deployment web --image=quay.io/ocp4git/nginx-web
kubectl -n frontend expose deployment web --name=web --port=80
kubectl -n frontend create deployment app --image=quay.io/ocp4git/nginx-app
kubectl -n frontend expose deployment app --name=app --port=80

kubectl create ns test
kubectl -n test create deployment blue --image=quay.io/ocp4git/app-blue
kubectl -n test expose deployment blue --name=blue --port=80
kubectl -n test create deployment red --image=quay.io/ocp4git/app-red
kubectl -n test expose deployment red --name=red --port=80

