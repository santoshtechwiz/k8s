This lab does not have any files. 
Solution is in the PDF itself. Follow the instructions there.
